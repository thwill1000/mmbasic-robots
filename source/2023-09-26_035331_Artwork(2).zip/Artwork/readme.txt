tiles\TL0*.SPR   			normal Tiles 24x24
tiles\TLA*.SPR   			Tiles for Animation 24x24

items\ITM*.SPR   			ITEMS 48x24
sprites\KEY*.SPR			3 Keycards 16x16
sprites\Spr_csub.bas  			all 256 Sprites 24x24 as csub
sprites\spr-Files\SP0*.spr  		Sprite Files that are included in the CSUB
sprites\Hlt.csub			6 Health Stages 48x48

Images\introscreen.bmp			Intro Screen (Startmenu)
Images\end.bmp				Game end, results
Images\Layer.bmp			Layer for the L Frame
